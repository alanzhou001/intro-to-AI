### 储存变量
name = 'Lulu'

# ### 与终端互动 01
# name = input('What\'s your name?')
# print('Hello', name)
#
# ### 与终端互动 02：另一种输出方式
# name = input('What\'s your name?')
# print(f'Hello, {name}') #不可以删除f
#
# ### 字符串
# 'Hello' + 'Lulu' #与print不同，中间没有空格
# 'Lulu'*3
#
# a='Lulu'
# a[2]
# a[0:3]
#
# ###储存数字 01
# x = input("What's x? ")
# y = input("What's y? ")
# print(x + y)
#
# ###储存数字 02: 转换格式
# x = int(input("What's x? "))
# y = int(input("What's y? "))
# print(x + y)