### 定义函数
def add(x, y):
    """This is comment: Add number x and y"""
    result=x+y
    return result

add(3,4)
"""This is not comment """


# ### 与终端互动
# x = int(input("What's x? "))
# y = int(input("What's y? "))
#
# print(add(x,y))
#
# ### 主函数 01
# def main():
#     x = int(input("What's x? "))
#     y = int(input("What's y? "))
#     print(add(x, y))
#
# main()
#
# ### 主函数 02
# if __name__ == "__main__":
#     main()