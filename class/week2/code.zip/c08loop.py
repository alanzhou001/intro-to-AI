print('meow')
print('meow')
print('meow')


### while loop
i = 1
while i <= 3:
    print("meow")
    i = i + 1


### for loop
for i in [0, 1, 2]:
    print("meow")


for i in range(3):
    print(i)
    print("meow")

# ### 模拟终端python
# while True:
#     line = input('>>>')
#     if line == 'quit()':
#         break
#     print(line)


